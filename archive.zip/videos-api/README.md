# videos-api
Run script postgres-videoDB/init_db.sh to initialize and run the docker container with postgres database.
